Tiny Weapon Shop V0.1 Alpha

new features from AoF V0.11C:
PLAAF AAMs
Swedish AAMs
Falcon series of AAMs
British AAMs
Italian AAMs
Brazilian AAMs
Israeli AAMs


upcoming (in no particular order and not necessarily next update):
AGM-130
GBU-15
Soviet/Russian AGMs


place in /Mods/ in your TCA directory, set up loadouts yourself or wait until Why485 adds customizable loadouts ingame
includes 140+ weapons from varying nations and eras, all with the most accurate specifications that i can legally find
will include more weapons in the future with more functionality and documentation

credits:
Why485 for Tiny Combat Arena and its wonderful moddability and assets as reference
@Ghaaaaa for most of the US air to ground weapon models
@nuclearstonk for all of the AAMs and all of the .json work
ravenclaw_007 for beautiful, highly detailed and accurate visual models, that we have used as references to build our own models off of

sources:
for sources of data for jsons, i primarily try to find research papers for the most accurate data, then go to DCS/BMS forums if there's data possible, then secretprojects forum, then WT forums, then sites like globalsecurity.com/missilery.info, corroborated with DCS data values, and if possible i scour RU forums for data mentions of these systems given their fearlessness of persecution and willingness to argue until one side shows data from physical books in a neatly organized digital medium.

license:
ask me (@nuclearstonk) for permission to republish this mod, and make proper crediting of the authors if you are granted permission

have fun! ^w^