Arsenal Of Freedom V0.11 Release

newest features in 0.10:
yet more russian AAMs
french AAMs
probably some other stuff i dont remember

upcoming (in no particular order and not necessarily next update):
falcon series of AAMs
figure out what the heck to do with the mod name or the pact weapons given that the soviet union wasn't particularly known for its personal freedoms, maybe a submod? i'd like feedback on this

place in /Mods/ in your TCA directory, set up loadouts yourself or wait until why485 adds customizable loadouts ingame
includes 140+ weapons from varying nations and eras, all with the most accurate specifications that i can legally find
will include more weapons in the future with more functionality and documentation

credits to @nuclearstonk and @taktischesgenie on discord

have fun! ^w^